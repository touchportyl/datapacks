#bossbar remove racetotheend:locator/fortress
scoreboard objectives remove RE_fortressdist