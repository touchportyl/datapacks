scoreboard objectives remove RE_lobby
scoreboard objectives remove RE_start
scoreboard objectives remove RE_stop
scoreboard objectives remove RE_assist