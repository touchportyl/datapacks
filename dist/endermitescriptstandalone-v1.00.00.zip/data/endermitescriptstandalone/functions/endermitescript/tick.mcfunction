# parser
execute as @e[type=endermite] at @s run function endermitescriptstandalone:endermitescript/parse


# traffic light
# blinker
function endermitescriptstandalone:endermitescript/trafficlight/functions/walksignal/blinker


# loop
schedule function endermitescriptstandalone:endermitescript/tick 1t