execute as @e[tag=endermitescriptstandalone,tag=trafficlight,distance=..2,sort=nearest,limit=1] at @s if block ^ ^ ^1 minecraft:light[level=15] run setblock ^ ^ ^1 minecraft:air replace
execute as @e[tag=endermitescriptstandalone,tag=trafficlight,distance=..2,sort=nearest,limit=1] at @s if block ~ ~1 ~ minecraft:player_wall_head run setblock ~ ~1 ~ minecraft:air replace
execute as @e[tag=endermitescriptstandalone,tag=trafficlight,distance=..2,sort=nearest,limit=1] at @s if block ~ ~ ~ minecraft:player_wall_head run setblock ~ ~ ~ minecraft:air replace

kill @e[tag=endermitescriptstandalone,tag=trafficlight,distance=..2,sort=nearest,limit=1]