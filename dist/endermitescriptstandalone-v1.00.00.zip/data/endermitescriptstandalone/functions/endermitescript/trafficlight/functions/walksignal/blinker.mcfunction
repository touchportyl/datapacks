# hardcoded blinker sound
scoreboard players add $trafficlight_blinker EMS_variables 1

execute if score $trafficlight_blinker EMS_variables matches 4.. as @e[tag=trafficlight,tag=walksignal,tag=blinker] at @s run playsound minecraft:block.note_block.iron_xylophone block @a[tag=!disable_traffic_blinker_sound,distance=..16] ~ ~ ~ 0.01 1.3 0

execute if score $trafficlight_blinker EMS_variables matches 4.. run scoreboard players set $trafficlight_blinker EMS_variables 0