# reset
kill @e[tag=ems_parsed]

# remove scoreboards
scoreboard objectives remove EMS_variables

# disable
datapack disable "endermitescriptstandalone-v1.00.00"