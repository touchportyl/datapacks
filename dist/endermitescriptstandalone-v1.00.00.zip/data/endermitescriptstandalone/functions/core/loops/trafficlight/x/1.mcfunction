# traffic cycle table
# |---------------|---------------------|-------------|-------------------|----------|
# | traffic light | traffic light (alt) | walk signal | walk signal (alt) | duration |
# |---------------|---------------------|-------------|-------------------|----------|
# | green         | red                 | red         | green             | 6s       |
# | green         | red                 | red         | red               | 4s       |
# | red           | red                 | red         | red               | 2s       |
# | red           | green               | green       | red               | 6s       |
# | red           | green               | red         | red               | 4s       |
# | red           | red                 | red         | red               | 2s       |
# |---------------|---------------------|-------------|-------------------|----------|

# reset
function endermitescriptstandalone:endermitescript/trafficlight/functions/trafficlight/reset_x
function endermitescriptstandalone:endermitescript/trafficlight/functions/walksignal/reset_x

# traffic light
function endermitescriptstandalone:endermitescript/trafficlight/functions/trafficlight/set_green_x
function endermitescriptstandalone:endermitescript/trafficlight/functions/trafficlight/set_red_x_alt

# walk signal
function endermitescriptstandalone:endermitescript/trafficlight/functions/walksignal/set_red_x
function endermitescriptstandalone:endermitescript/trafficlight/functions/walksignal/set_green_x_alt

# schedule next
schedule function endermitescriptstandalone:core/loops/trafficlight/x/2 6s