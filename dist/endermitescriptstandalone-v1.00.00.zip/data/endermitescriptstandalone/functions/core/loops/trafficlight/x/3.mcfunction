# reset
function endermitescriptstandalone:endermitescript/trafficlight/functions/trafficlight/reset_x
function endermitescriptstandalone:endermitescript/trafficlight/functions/walksignal/reset_x

# traffic light
function endermitescriptstandalone:endermitescript/trafficlight/functions/trafficlight/set_red_x
function endermitescriptstandalone:endermitescript/trafficlight/functions/trafficlight/set_red_x_alt

# walk signal
function endermitescriptstandalone:endermitescript/trafficlight/functions/walksignal/set_red_x
function endermitescriptstandalone:endermitescript/trafficlight/functions/walksignal/set_red_x_alt

# schedule next
schedule function endermitescriptstandalone:core/loops/trafficlight/x/4 2s