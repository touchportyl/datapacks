# reset
function endermitescriptstandalone:endermitescript/trafficlight/functions/trafficlight/reset
function endermitescriptstandalone:endermitescript/trafficlight/functions/walksignal/reset

# traffic light
function endermitescriptstandalone:endermitescript/trafficlight/functions/trafficlight/set_red

# walk signal
function endermitescriptstandalone:endermitescript/trafficlight/functions/walksignal/set_red

# schedule next
schedule function endermitescriptstandalone:core/loops/trafficlight/straight/1 2s