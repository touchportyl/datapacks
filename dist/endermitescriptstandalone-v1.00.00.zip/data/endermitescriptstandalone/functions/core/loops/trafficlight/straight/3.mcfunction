# reset
function endermitescriptstandalone:endermitescript/trafficlight/functions/trafficlight/reset
function endermitescriptstandalone:endermitescript/trafficlight/functions/walksignal/reset

# traffic light
function endermitescriptstandalone:endermitescript/trafficlight/functions/trafficlight/set_red

# walk signal
function endermitescriptstandalone:endermitescript/trafficlight/functions/walksignal/set_green

# schedule next
schedule function endermitescriptstandalone:core/loops/trafficlight/straight/4 6s