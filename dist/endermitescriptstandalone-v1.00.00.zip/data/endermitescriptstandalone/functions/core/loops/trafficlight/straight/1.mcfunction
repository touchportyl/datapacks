# traffic cycle table
# |---------------|-------------|----------|
# | traffic light | walk signal | duration |
# |---------------|-------------|----------|
# | green         | red         | 6s       |
# | red           | red         | 2s       |
# | red           | green       | 6s       |
# | red           | red         | 2s       |
# |---------------|-------------|----------|

# reset
function endermitescriptstandalone:endermitescript/trafficlight/functions/trafficlight/reset
function endermitescriptstandalone:endermitescript/trafficlight/functions/walksignal/reset

# traffic light
function endermitescriptstandalone:endermitescript/trafficlight/functions/trafficlight/set_green

# walk signal
function endermitescriptstandalone:endermitescript/trafficlight/functions/walksignal/set_red

# schedule next
schedule function endermitescriptstandalone:core/loops/trafficlight/straight/2 6s