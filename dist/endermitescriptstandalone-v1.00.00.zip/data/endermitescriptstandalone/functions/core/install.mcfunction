tellraw @a[tag=developer] {"text":""}
tellraw @a[tag=developer] [{"text":"","color":"gray"},{"text":"This server is running "},{"text":"Endermite Script Standalone v1.00.00","color":"white","underlined":true},{"text":" by "},{"text":"touchportyl","color":"light_purple"}]

# clear schedules
schedule clear endermitescriptstandalone:endermitescript/tick
schedule clear endermitescriptstandalone:core/loops/blinkingredstonelamp/unlit
schedule clear endermitescriptstandalone:core/loops/blinkingredstonelamp/lit
schedule clear endermitescriptstandalone:core/loops/trafficlight/straight/1
schedule clear endermitescriptstandalone:core/loops/trafficlight/straight/2
schedule clear endermitescriptstandalone:core/loops/trafficlight/x/1
schedule clear endermitescriptstandalone:core/loops/trafficlight/x/2
schedule clear endermitescriptstandalone:core/loops/trafficlight/x/3
schedule clear endermitescriptstandalone:core/loops/trafficlight/x/4
schedule clear endermitescriptstandalone:core/loops/trafficlight/x/5
schedule clear endermitescriptstandalone:core/loops/trafficlight/x/6


# define scoreboards
scoreboard objectives add EMS_variables dummy {"text":"Endermite Script Standalone Variables"}


# start tickers
schedule function endermitescriptstandalone:core/loops/blinkingredstonelamp/unlit 1s
schedule function endermitescriptstandalone:core/loops/trafficlight/straight/1 1s
schedule function endermitescriptstandalone:core/loops/trafficlight/x/1 1s


# start endermite script
schedule function endermitescriptstandalone:endermitescript/tick 1s