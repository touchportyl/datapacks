# for tracking any breaking updates

# v3.01.00 -> v3.02.00
- add new particle tag (DD_particle_C) to existing oak doors (DD_portal, DD_oak)
- create new config triggers (z_dd_001_t, etc.) for datapack manager
- update door rotation placement
- replace AECs with marker armorstands

# v3.00.00 -> v3.01.00
- change color (light_purple) of "DimensionalDoors"
- move DD$secret DimensionalDoors to FLAG$secret DimensionalDoors
- change color (light_purple) and name (Door ID) of "DD_doorID"