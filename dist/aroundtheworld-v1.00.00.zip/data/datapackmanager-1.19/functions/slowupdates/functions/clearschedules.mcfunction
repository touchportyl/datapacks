tellraw @a[tag=dm_debug] [{"text":"DM > slowupdates/functions/clearschedules.mcfunction","color":"gray"}]

# stop loops
schedule clear datapackmanager-1.19:tickers/1s
