tellraw @a[tag=dm_debug] [{"text":"DM > slowupdates/functions/cleanuninstall.mcfunction","color":"gray"}]

# stop loops
function datapackmanager-1.19:slowupdates/functions/clearschedules


# kill entities
kill @e[type=!player,tag=DatapackManager]


# purge items
# remove items from all tracked inventories


# remove tags
tag @a remove dm_debug


# wipe scoreboards
#scoreboard objectives remove uninstall
scoreboard objectives remove DatapackManager