# compatibility for 1.13
execute unless score DM$first DatapackManager matches 1 if score DM$noschedulecommand DatapackManager = BOOL$true DatapackManager run function datapackmanager-1.19:tickers/1t
