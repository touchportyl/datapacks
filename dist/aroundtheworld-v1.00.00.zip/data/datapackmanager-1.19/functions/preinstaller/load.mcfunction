tellraw @a[tag=dm_debug] [{"text":"DM > preinstaller/load.mcfunction","color":"gray"}]

# create master scoreboard
# WARNING: THIS COMMAND MUST RUN BEFORE ANYTHING ELSE
scoreboard objectives add DatapackManager dummy [{"text":"Datapack Manager","color":"white"}]

# initialize
# the first manager that runs will disable all other managers
execute unless score DM$first DatapackManager matches 1 run function datapackmanager-1.19:preinstaller/initialize