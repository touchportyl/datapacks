tellraw @a[tag=dm_debug] [{"text":"DM > preinstaller/initialize.mcfunction","color":"gray"}]

# win the race condition
scoreboard players set DM$first DatapackManager 1
# remember to set this back after 3 seconds

# create triggers
#scoreboard objectives add uninstall trigger

# set constants
scoreboard players set DM$secret DatapackManager 259240

scoreboard players set BOOL$false DatapackManager 0
scoreboard players set BOOL$true DatapackManager 1

scoreboard players set NUMBER$one DatapackManager 1
scoreboard players set NUMBER$two DatapackManager 2
scoreboard players set NUMBER$three DatapackManager 3
scoreboard players set NUMBER$four DatapackManager 4
scoreboard players set NUMBER$five DatapackManager 5
scoreboard players set NUMBER$six DatapackManager 6
scoreboard players set NUMBER$seven DatapackManager 7
scoreboard players set NUMBER$eight DatapackManager 8
scoreboard players set NUMBER$nine DatapackManager 9

# load config
scoreboard players operation FUNCTION$loadconfig DatapackManager = BOOL$true DatapackManager
# force to run inline
function datapackmanager-1.19:slowupdates/update

# check minecraft version
function datapackmanager-1.19:versioning/check

# start tickers
# INLINE VERSIONING
execute if score VERSION$minecraft.current DatapackManager matches 13 run scoreboard players operation DM$noschedulecommand DatapackManager = BOOL$true DatapackManager
execute if score VERSION$minecraft.current DatapackManager matches 14..19 run function datapackmanager-1.19:tickers/1s

# custom notification
scoreboard players operation ALERT$minecraftversion DatapackManager = BOOL$true DatapackManager
scoreboard players operation DM$dirty DatapackManager = BOOL$true DatapackManager

# push state to all listening datapacks
# Datapack Manager only supports 1.14 to 1.19
execute if score VERSION$minecraft.current DatapackManager matches 14..19 run scoreboard players operation DM$active DatapackManager = BOOL$true DatapackManager

# cleanup
execute unless score VERSION$minecraft.current DatapackManager matches 14..19 run function datapackmanager-1.19:preinstaller/resetdmfirst

schedule function datapackmanager-1.19:preinstaller/resetdmfirst 3s