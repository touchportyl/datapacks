tellraw @a[tag=dm_debug] [{"text":"DM > versioning/throw/notcompatible.mcfunction","color":"gray"}]

scoreboard players operation ALERT$mcnotcompatible DatapackManager = BOOL$true DatapackManager
scoreboard players operation DM$dirty DatapackManager = BOOL$true DatapackManager
