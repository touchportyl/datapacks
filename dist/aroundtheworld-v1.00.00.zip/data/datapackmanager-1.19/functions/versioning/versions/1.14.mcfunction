tellraw @a[tag=dm_debug] [{"text":"DM > versioning/versions/1.14.mcfunction","color":"gray"}]

particle minecraft:campfire_cosy_smoke ~ 0 ~ 0 0 0 1 1
scoreboard players set VERSION$minecraft.current DatapackManager 14
