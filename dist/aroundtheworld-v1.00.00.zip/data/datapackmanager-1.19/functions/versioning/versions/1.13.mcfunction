tellraw @a[tag=dm_debug] [{"text":"DM > versioning/versions/1.13.mcfunction","color":"gray"}]

particle minecraft:flame ~ 0 ~ 0 0 0 1 1
scoreboard players set VERSION$minecraft.current DatapackManager 13
