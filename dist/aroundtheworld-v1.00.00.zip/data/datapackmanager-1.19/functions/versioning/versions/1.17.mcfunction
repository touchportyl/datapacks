tellraw @a[tag=dm_debug] [{"text":"DM > versioning/versions/1.17.mcfunction","color":"gray"}]

particle minecraft:glow_squid_ink ~ 0 ~ 0 0 0 1 1
scoreboard players set VERSION$minecraft.current DatapackManager 17
