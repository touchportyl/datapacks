execute if score DM$dirty DatapackManager = BOOL$true DatapackManager run function datapackmanager-1.19:slowupdates/update

scoreboard players operation DM$noschedulecommand DatapackManager = BOOL$false DatapackManager

# tick
schedule function datapackmanager-1.19:tickers/1s 1s
