tellraw @a[tag=aw_debug] [{"text":"AW > installer-v1.00.00.mcfunction","color":"gray"}]

# write your installation code here

# create scoreboards
# create bossbars
# set variables
# start datapack