tellraw @a[tag=aw_debug] [{"text":"AW > config.mcfunction","color":"gray"}]

# add your own datapack configuration settings here

# code use example:
# execute if CONFIG$addyourown AroundTheWorld = BOOL$true DatapackManager run say "This code runs because addyourown is enabled in the config."

#scoreboard players set CONFIG$min.x AroundTheWorld -6400
#scoreboard players set CONFIG$max.x AroundTheWorld 2400
#scoreboard players set CONFIG$min.z AroundTheWorld -1900
#scoreboard players set CONFIG$max.z AroundTheWorld 2900


# WARNING: ONLY CHANGE THESE CONFIGURATION OPTIONS IF YOU KNOW WHAT YOU'RE DOING
# CHANGING THESE SETTINGS COULD FORCE THE DATAPACK TO RUN COMMANDS THAT IT SHOULDN'T

# set the datapack's current version
scoreboard players set VERSION$datapack.current AroundTheWorld 10000

# set the backward and forward compatible minecraft versions
scoreboard players set VERSION$minecraft.backward AroundTheWorld 14
scoreboard players set VERSION$minecraft.forward AroundTheWorld 19

# special override to run this datapack on other versions
scoreboard players operation VERSION$ignorecompatibility.backward AroundTheWorld = BOOL$false DatapackManager
scoreboard players operation VERSION$ignorecompatibility.forward AroundTheWorld = BOOL$false DatapackManager