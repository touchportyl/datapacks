tellraw @a[tag=aw_debug] [{"text":"AW > packages/preinstaller/initialize.mcfunction","color":"gray"}]

# create master scoreboard
# WARNING: THIS COMMAND MUST RUN BEFORE ANYTHING ELSE
scoreboard objectives add AroundTheWorld dummy [{"text":"Around the World","color":"blue"}]

# load config
scoreboard players operation FUNCTION$loadconfig AroundTheWorld = BOOL$true DatapackManager
# force to run inline
function aroundtheworld:packages/slowupdates/update

# check datapack version
function aroundtheworld:packages/versioning/check

# start tickers
function aroundtheworld:packages/tickers/1t-v1.00.00
function aroundtheworld:packages/tickers/1s-v1.00.00

# initialize
execute unless score AW$secret AroundTheWorld = DM$secret DatapackManager run function aroundtheworld:installer-v1.00.00
