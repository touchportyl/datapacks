# listen for datapack manager
execute if score DM$active DatapackManager = BOOL$true DatapackManager run function aroundtheworld:packages/preinstaller/initialize

# ticker
execute unless score DM$active DatapackManager = BOOL$true DatapackManager run schedule function aroundtheworld:packages/preinstaller/listen 2t