tellraw @a[tag=aw_debug] [{"text":"AW > packages/preinstaller/load.mcfunction","color":"gray"}]

# create listener
function aroundtheworld:packages/preinstaller/listen