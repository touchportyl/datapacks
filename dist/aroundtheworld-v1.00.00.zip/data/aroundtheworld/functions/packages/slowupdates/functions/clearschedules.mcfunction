tellraw @a[tag=aw_debug] [{"text":"AW > packages/slowupdates/functions/clearschedules.mcfunction","color":"gray"}]

# stop loops
schedule clear aroundtheworld:packages/tickers/1t-v1.00.00
schedule clear aroundtheworld:packages/tickers/1s-v1.00.00