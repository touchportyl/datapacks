tellraw @a[tag=aw_debug] [{"text":"AW > packages/slowupdates/functions/loadconfig.mcfunction","color":"gray"}]

# notify
function datapackmanager-1.19:slowupdates/alerts/configurationloaded

# default values
scoreboard players set VERSION$datapack.current DatapackManager 10000

# load
function aroundtheworld:config
