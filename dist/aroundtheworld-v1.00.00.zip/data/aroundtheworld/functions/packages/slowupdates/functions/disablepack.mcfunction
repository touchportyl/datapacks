tellraw @a[tag=aw_debug] [{"text":"AW > packages/slowupdates/functions/disablepack.mcfunction","color":"gray"}]

# notify
function datapackmanager-1.19:slowupdates/alerts/datapackdisabled

# disable pack
datapack disable "file/aroundtheworld-v1.00.00.zip"
datapack disable "file/aroundtheworld-v1.00.00"