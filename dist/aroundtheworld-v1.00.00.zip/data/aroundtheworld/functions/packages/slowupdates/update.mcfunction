tellraw @a[tag=aw_debug] [{"text":"AW > packages/slowupdates/update.mcfunction","color":"gray"}]

# alerts
execute if score ALERT$mcnotcompatible AroundTheWorld = BOOL$true DatapackManager run function aroundtheworld:packages/slowupdates/alerts/minecraftnotcompatible

# functions
execute if score FUNCTION$clearschedules AroundTheWorld = BOOL$true DatapackManager run function aroundtheworld:packages/slowupdates/functions/clearschedules
execute if score FUNCTION$disablepack AroundTheWorld = BOOL$true DatapackManager run function aroundtheworld:packages/slowupdates/functions/disablepack
execute if score FUNCTION$loadconfig AroundTheWorld = BOOL$true DatapackManager run function aroundtheworld:packages/slowupdates/functions/loadconfig
execute if score FUNCTION$uninstall AroundTheWorld = BOOL$true DatapackManager run function aroundtheworld:packages/slowupdates/functions/uninstall


# cleanup
scoreboard players operation ALERT$mcnotcompatible AroundTheWorld = BOOL$false DatapackManager

scoreboard players operation FUNCTION$clearschedules AroundTheWorld = BOOL$false DatapackManager
scoreboard players operation FUNCTION$disablepack AroundTheWorld = BOOL$false DatapackManager
scoreboard players operation FUNCTION$loadconfig AroundTheWorld = BOOL$false DatapackManager
scoreboard players operation FUNCTION$uninstall AroundTheWorld = BOOL$false DatapackManager

scoreboard players operation AW$dirty AroundTheWorld = BOOL$false DatapackManager


# callback
scoreboard players operation DM$dirty DatapackManager = BOOL$true DatapackManager
