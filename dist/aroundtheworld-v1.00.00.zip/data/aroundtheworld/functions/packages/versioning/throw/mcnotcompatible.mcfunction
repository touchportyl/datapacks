tellraw @a[tag=aw_debug] [{"text":"AW > packages/versioning/throw/mcnotcompatible.mcfunction","color":"gray"}]

scoreboard players operation ALERT$mcnotcompatible AroundTheWorld = BOOL$true DatapackManager
scoreboard players operation VERSION$datapack.latest AroundTheWorld = VERSION$datapack.current AroundTheWorld

function aroundtheworld:packages/slowupdates/functions/disablepack

scoreboard players operation AW$dirty AroundTheWorld = BOOL$true DatapackManager