tellraw @a[tag=aw_debug] [{"text":"AW > packages/versioning/updates/v2.00.00.mcfunction","color":"gray"}]

# update
scoreboard players set VERSION$datapack.latest AroundTheWorld 20000
