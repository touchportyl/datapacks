# notify
tellraw @s [{"text":"","color":"green","hoverEvent":{"action":"show_text","value":"Alert from Datapack Manager"}},{"text":" +"},{"text":" Datapack Manager ","color":"white","bold":true,"hoverEvent":{"action":"show_text","value":"Structured and standardized for all!"}},{"text":"mc1.21","color":"gray"},{"text":" > ","color":"white"},{"text":"Loaded the default configuration file."}]

function datapackmanager-1.21:packages/effects/ui/jingle